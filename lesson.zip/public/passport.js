/**
 * AURA ROYAL GOLD - MY PASSPORT PAGE SCRIPT
 */

const API_BASE = (window.location.protocol === 'http:' || window.location.protocol === 'https:') && window.location.port === '4040'
  ? ''
  : 'http://localhost:4040';

const passportCardWrap = document.getElementById('passportCardWrap');
const logoutBtn = document.getElementById('logoutBtn');
const toastContainer = document.getElementById('toastContainer');

document.addEventListener('DOMContentLoaded', init);
logoutBtn.addEventListener('click', logout);

async function init() {
  const token = localStorage.getItem('auraToken');
  if (!token) {
    window.location.href = 'login.html';
    return;
  }

  passportCardWrap.innerHTML = `
    <div class="loading-state-card" style="margin-top: 40px;">
      <div class="gold-spinner"></div>
      <p>Pasport ma'lumotlari yuklanmoqda...</p>
    </div>
  `;

  try {
    const res = await fetch(`${API_BASE}/me`, {
      headers: { Authorization: `Bearer ${token}` }
    });

    if (res.status === 401 || res.status === 403) {
      localStorage.removeItem('auraToken');
      localStorage.removeItem('auraUser');
      window.location.href = 'login.html';
      return;
    }

    if (!res.ok) {
      throw new Error('Ma\'lumotlarni yuklab bo\'lmadi');
    }

    const user = await res.json();
    localStorage.setItem('auraUser', JSON.stringify(user));

    // Admins land on their own passport too if they navigate here directly,
    // but their main destination is the admin panel.
    passportCardWrap.innerHTML = buildPassportCardHTML(user);

    if (user.role === 'admin') {
      const adminLinkHTML = `
        <a href="index.html" class="btn-gold-outline" style="margin-top: 22px; text-decoration:none; display:inline-flex;">
          <i class="fa-solid fa-crown"></i><span>Admin panelga o'tish</span>
        </a>
      `;
      passportCardWrap.insertAdjacentHTML('beforeend', adminLinkHTML);
    }
  } catch (err) {
    console.error(err);
    passportCardWrap.innerHTML = `
      <div class="empty-state-card" style="display:flex;">
        <div class="empty-icon-glow"><i class="fa-solid fa-triangle-exclamation"></i></div>
        <h3 class="empty-title">Pasportni yuklab bo'lmadi</h3>
        <p class="empty-desc">${escapeHTML(err.message)}</p>
      </div>
    `;
  }
}

function logout() {
  localStorage.removeItem('auraToken');
  localStorage.removeItem('auraUser');
  window.location.href = 'login.html';
}

function escapeHTML(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
