﻿/**
 * AURA ROYAL GOLD - FRONTEND APPLICATION SCRIPT
 * Connects to Express backend on port 4040
 * Features: Complete CRUD (Create, Read, Update/Change, Delete), Search, Sort, Metrics
 */

// Determine API Base URL dynamically
const API_BASE = (window.location.protocol === 'http:' || window.location.protocol === 'https:') && window.location.port === '4040'
  ? ''
  : 'http://localhost:4040';

// Global State
let allUsers = [];
let activeView = 'grid'; // 'grid' or 'table'
let currentDeleteUser = null;

// ==================== AUTH HELPERS (Admin-only panel) ====================

function getAuthToken() {
  return localStorage.getItem('auraToken');
}

function authHeaders(extra = {}) {
  const token = getAuthToken();
  return token ? { ...extra, Authorization: `Bearer ${token}` } : extra;
}

function logout() {
  localStorage.removeItem('auraToken');
  localStorage.removeItem('auraUser');
  window.location.href = 'login.html';
}

/**
 * This whole page is a private admin panel. Every visitor is checked
 * against /me before anything loads; non-admins are bounced to login.html.
 */
async function guardAdminAccess() {
  const token = getAuthToken();
  if (!token) {
    window.location.href = 'login.html';
    return false;
  }

  try {
    const res = await fetch(`${API_BASE}/me`, { headers: authHeaders() });
    if (!res.ok) throw new Error('Session invalid');
    const user = await res.json();

    if (user.role !== 'admin') {
      // Logged-in but not an admin: send them to their own passport page instead.
      window.location.href = 'passport.html';
      return false;
    }

    localStorage.setItem('auraUser', JSON.stringify(user));
    return true;
  } catch (err) {
    localStorage.removeItem('auraToken');
    localStorage.removeItem('auraUser');
    window.location.href = 'login.html';
    return false;
  }
}

// DOM Elements
const backendStatusPill = document.getElementById('backendStatusPill');
const statusDot = document.getElementById('statusDot');
const statusLabel = document.getElementById('statusLabel');
const refreshBtn = document.getElementById('refreshBtn');

// Stat Elements
const statTotalUsers = document.getElementById('statTotalUsers');
const statNextId = document.getElementById('statNextId');
const statAvgAge = document.getElementById('statAvgAge');
const anticipatedIdBadge = document.getElementById('anticipatedIdBadge');
const recordsCountBadge = document.getElementById('recordsCountBadge');

// Forms & Inputs
const createUserForm = document.getElementById('createUserForm');
const fullnameInput = document.getElementById('fullname');
const ageInput = document.getElementById('age');
const createUserBtn = document.getElementById('createUserBtn');

// Directory Controls
const searchInput = document.getElementById('searchInput');
const clearSearchBtn = document.getElementById('clearSearchBtn');
const sortSelect = document.getElementById('sortSelect');
const gridViewBtn = document.getElementById('gridViewBtn');
const tableViewBtn = document.getElementById('tableViewBtn');

// Content Containers
const usersCardsGrid = document.getElementById('usersCardsGrid');
const usersTableContainer = document.getElementById('usersTableContainer');
const usersTableBody = document.getElementById('usersTableBody');
const emptyState = document.getElementById('emptyState');
const loadingState = document.getElementById('loadingState');

// Edit Modal Elements
const editModal = document.getElementById('editModal');
const closeEditModalBtn = document.getElementById('closeEditModalBtn');
const cancelEditBtn = document.getElementById('cancelEditBtn');
const editUserForm = document.getElementById('editUserForm');
const editUserId = document.getElementById('editUserId');
const editUserIdBadge = document.getElementById('editUserIdBadge');
const editFullname = document.getElementById('editFullname');
const editAge = document.getElementById('editAge');

// Delete Modal Elements
const deleteModal = document.getElementById('deleteModal');
const closeDeleteModalBtn = document.getElementById('closeDeleteModalBtn');
const cancelDeleteBtn = document.getElementById('cancelDeleteBtn');
const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
const deleteTargetId = document.getElementById('deleteTargetId');
const deleteTargetName = document.getElementById('deleteTargetName');

// Toast Container
const toastContainer = document.getElementById('toastContainer');

// Passport Modal Elements
const passportModal = document.getElementById('passportModal');
const passportModalBody = document.getElementById('passportModalBody');

// ==================== INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', async () => {
  const allowed = await guardAdminAccess();
  if (!allowed) return;

  initEventListeners();
  loadUsers();
});

// ==================== EVENT LISTENERS ====================
function initEventListeners() {
  // Refresh Button
  refreshBtn.addEventListener('click', () => {
    refreshBtn.classList.add('rotating');
    loadUsers().finally(() => {
      setTimeout(() => refreshBtn.classList.remove('rotating'), 600);
    });
  });

  // Logout Button
  document.getElementById('logoutBtn').addEventListener('click', logout);

  // Passport Modal
  document.getElementById('closePassportModalBtn').addEventListener('click', closePassportModal);
  passportModal.addEventListener('click', (e) => {
    if (e.target === passportModal) closePassportModal();
  });

  // Create User Form
  createUserForm.addEventListener('submit', handleCreateUser);

  // Search Input
  searchInput.addEventListener('input', () => {
    if (searchInput.value.trim().length > 0) {
      clearSearchBtn.style.display = 'block';
    } else {
      clearSearchBtn.style.display = 'none';
    }
    renderUsers();
  });

  clearSearchBtn.addEventListener('click', () => {
    searchInput.value = '';
    clearSearchBtn.style.display = 'none';
    searchInput.focus();
    renderUsers();
  });

  // Sort Select
  sortSelect.addEventListener('change', () => {
    renderUsers();
  });

  // View Switchers
  gridViewBtn.addEventListener('click', () => {
    activeView = 'grid';
    gridViewBtn.classList.add('active');
    tableViewBtn.classList.remove('active');
    usersCardsGrid.style.display = 'grid';
    usersTableContainer.style.display = 'none';
  });

  tableViewBtn.addEventListener('click', () => {
    activeView = 'table';
    tableViewBtn.classList.add('active');
    gridViewBtn.classList.remove('active');
    usersCardsGrid.style.display = 'none';
    usersTableContainer.style.display = 'block';
  });

  // Edit Modal Listeners
  closeEditModalBtn.addEventListener('click', closeEditModal);
  cancelEditBtn.addEventListener('click', closeEditModal);
  editUserForm.addEventListener('submit', handleUpdateUser);

  // Delete Modal Listeners
  closeDeleteModalBtn.addEventListener('click', closeDeleteModal);
  cancelDeleteBtn.addEventListener('click', closeDeleteModal);
  confirmDeleteBtn.addEventListener('click', handleConfirmDelete);

  // Modal Backdrop Click & Escape Key
  [editModal, deleteModal].forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        closeEditModal();
        closeDeleteModal();
      }
    });
  });

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeEditModal();
      closeDeleteModal();
      closePassportModal();
    }
  });
}

// ==================== API OPERATIONS ====================

/**
 * Fetch all users from the Express backend
 */
async function loadUsers() {
  try {
    const response = await fetch(`${API_BASE}/users`, { headers: authHeaders() });
    if (response.status === 401 || response.status === 403) {
      logout();
      return;
    }
    if (!response.ok) {
      throw new Error(`Server returned status ${response.status}`);
    }

    const data = await response.json();
    allUsers = Array.isArray(data) ? data : [];

    setBackendStatus(true);
    updateMetrics();
    renderUsers();
  } catch (error) {
    console.error('Failed to load users:', error);
    setBackendStatus(false);
    showToast(`Error connecting to backend: ${error.message}`, 'danger');
    renderUsers();
  } finally {
    loadingState.style.display = 'none';
  }
}

/**
 * Create a new user (POST /users)
 */
async function handleCreateUser(e) {
  e.preventDefault();

  const fullname = fullnameInput.value.trim();
  const age = parseInt(ageInput.value, 10);

  if (!fullname || isNaN(age)) {
    showToast('Please enter a valid fullname and age.', 'danger');
    return;
  }

  createUserBtn.disabled = true;
  createUserBtn.style.opacity = '0.7';

  try {
    const response = await fetch(`${API_BASE}/users`, {
      method: 'POST',
      headers: authHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ fullname, age })
    });

    if (!response.ok) {
      const errorMsg = await response.text();
      throw new Error(errorMsg || 'Failed to create user');
    }

    const newUser = await response.json();
    showToast(`Member #${newUser.id} (${newUser.fullname}) successfully created! ✨`, 'success');

    // Reset Form
    fullnameInput.value = '';
    ageInput.value = '';
    fullnameInput.focus();

    // Reload Users
    await loadUsers();
  } catch (error) {
    console.error('Error creating user:', error);
    showToast(`Failed to create member: ${error.message}`, 'danger');
  } finally {
    createUserBtn.disabled = false;
    createUserBtn.style.opacity = '1';
  }
}

/**
 * Update an existing user (PUT /users/:id)
 */
async function handleUpdateUser(e) {
  e.preventDefault();

  const id = parseInt(editUserId.value, 10);
  const fullname = editFullname.value.trim();
  const age = parseInt(editAge.value, 10);

  if (!id || !fullname || isNaN(age)) {
    showToast('Please enter valid details.', 'danger');
    return;
  }

  const saveBtn = document.getElementById('saveEditBtn');
  saveBtn.disabled = true;

  try {
    const response = await fetch(`${API_BASE}/users/${id}`, {
      method: 'PUT',
      headers: authHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ fullname, age })
    });

    if (!response.ok) {
      const errorMsg = await response.text();
      throw new Error(errorMsg || 'Failed to update user');
    }

    const updatedUser = await response.json();
    showToast(`Member #${updatedUser.id} updated successfully! ⚜️`, 'success');
    closeEditModal();
    await loadUsers();
  } catch (error) {
    console.error('Error updating user:', error);
    showToast(`Failed to update member: ${error.message}`, 'danger');
  } finally {
    saveBtn.disabled = false;
  }
}

/**
 * Delete a user (DELETE /users/:id)
 */
async function handleConfirmDelete() {
  if (!currentDeleteUser) return;

  confirmDeleteBtn.disabled = true;
  confirmDeleteBtn.style.opacity = '0.7';

  try {
    const response = await fetch(`${API_BASE}/users/${currentDeleteUser.id}`, {
      method: 'DELETE',
      headers: authHeaders()
    });

    if (!response.ok) {
      const errorMsg = await response.text();
      throw new Error(errorMsg || 'Failed to delete user');
    }

    showToast(`Member #${currentDeleteUser.id} (${currentDeleteUser.fullname}) has been removed.`, 'danger');
    closeDeleteModal();
    await loadUsers();
  } catch (error) {
    console.error('Error deleting user:', error);
    showToast(`Failed to delete member: ${error.message}`, 'danger');
  } finally {
    confirmDeleteBtn.disabled = false;
    confirmDeleteBtn.style.opacity = '1';
  }
}

// ==================== RENDERING ====================

/**
 * Filter, sort, and render users according to current view
 */
function renderUsers() {
  const query = searchInput.value.trim().toLowerCase();
  const sortMode = sortSelect.value;

  // Filter
  let filtered = allUsers.filter(u => {
    const matchName = (u.fullname || '').toLowerCase().includes(query);
    const matchId = String(u.id).includes(query);
    return matchName || matchId;
  });

  // Sort
  filtered.sort((a, b) => {
    switch (sortMode) {
      case 'id-asc':
        return a.id - b.id;
      case 'id-desc':
        return b.id - a.id;
      case 'name-asc':
        return (a.fullname || '').localeCompare(b.fullname || '');
      case 'name-desc':
        return (b.fullname || '').localeCompare(a.fullname || '');
      case 'age-asc':
        return a.age - b.age;
      case 'age-desc':
        return b.age - a.age;
      default:
        return a.id - b.id;
    }
  });

  // Update records count badge
  recordsCountBadge.textContent = `${filtered.length} Member${filtered.length === 1 ? '' : 's'}`;

  // Handle empty state
  if (filtered.length === 0) {
    usersCardsGrid.innerHTML = '';
    usersTableBody.innerHTML = '';
    emptyState.style.display = 'flex';
    return;
  }

  emptyState.style.display = 'none';

  // Render Grid Cards
  usersCardsGrid.innerHTML = filtered.map(user => createCardHTML(user)).join('');

  // Render Table Rows
  usersTableBody.innerHTML = filtered.map(user => createTableRowHTML(user)).join('');

  // Attach card & table button event handlers
  attachActionHandlers();
}

/**
 * Generate User Card HTML
 */
function createCardHTML(user) {
  const initials = getInitials(user.fullname);
  return `
    <div class="user-card" data-id="${user.id}">
      <div class="card-header">
        <span class="user-id-badge">#${user.id}</span>
        <span class="user-status-tag">Active</span>
      </div>

      <div class="card-body">
        <div class="user-avatar">${initials}</div>
        <div class="user-details">
          <h4 class="user-name" title="${escapeHTML(user.fullname)}">${escapeHTML(user.fullname)}</h4>
          <span class="user-age-pill">
            <i class="fa-solid fa-hourglass-half"></i> ${user.age} years old
          </span>
        </div>
      </div>

      <div class="card-actions">
        <button class="btn-card-action btn-edit" onclick="openPassportModal(${user.id})" title="View electronic passport">
          <i class="fa-solid fa-id-card-clip"></i> Passport
        </button>
        <button class="btn-card-action btn-edit" onclick="openEditModal(${user.id})">
          <i class="fa-solid fa-pen-to-square"></i> Edit
        </button>
        <button class="btn-card-action btn-delete" onclick="openDeleteModal(${user.id})">
          <i class="fa-solid fa-trash-can"></i> Delete
        </button>
      </div>
    </div>
  `;
}

/**
 * Generate Table Row HTML
 */
function createTableRowHTML(user) {
  const initials = getInitials(user.fullname);
  return `
    <tr data-id="${user.id}">
      <td>
        <span class="user-id-badge">#${user.id}</span>
      </td>
      <td>
        <div style="display: flex; align-items: center; gap: 12px;">
          <div class="user-avatar" style="width: 38px; height: 38px; font-size: 14px;">${initials}</div>
          <strong style="color: #fff; font-size: 14px;">${escapeHTML(user.fullname)}</strong>
        </div>
      </td>
      <td>
        <span class="user-age-pill">${user.age} yrs</span>
      </td>
      <td>
        <span class="user-status-tag">Active</span>
      </td>
      <td class="text-right">
        <div class="table-actions">
          <button class="btn-card-action btn-edit" style="padding: 6px 12px;" onclick="openPassportModal(${user.id})" title="View electronic passport">
            <i class="fa-solid fa-id-card-clip"></i>
          </button>
          <button class="btn-card-action btn-edit" style="padding: 6px 12px;" onclick="openEditModal(${user.id})">
            <i class="fa-solid fa-pen-to-square"></i> Edit
          </button>
          <button class="btn-card-action btn-delete" style="padding: 6px 12px;" onclick="openDeleteModal(${user.id})">
            <i class="fa-solid fa-trash-can"></i> Delete
          </button>
        </div>
      </td>
    </tr>
  `;
}

function attachActionHandlers() {
  // Handlers are bound inline through openEditModal and openDeleteModal
}

// ==================== MODAL HELPERS ====================

/**
 * Open Edit Modal for a specific user ID
 */
window.openEditModal = function(id) {
  const user = allUsers.find(u => u.id === id);
  if (!user) return;

  editUserId.value = user.id;
  editUserIdBadge.textContent = `#${user.id}`;
  editFullname.value = user.fullname;
  editAge.value = user.age;

  editModal.classList.add('active');
  editFullname.focus();
};

function closeEditModal() {
  editModal.classList.remove('active');
}

/**
 * Open Delete Confirmation Modal for a specific user ID
 */
window.openDeleteModal = function(id) {
  const user = allUsers.find(u => u.id === id);
  if (!user) return;

  currentDeleteUser = user;
  deleteTargetId.textContent = `#${user.id}`;
  deleteTargetName.textContent = user.fullname;

  deleteModal.classList.add('active');
};

function closeDeleteModal() {
  deleteModal.classList.remove('active');
  currentDeleteUser = null;
}

/**
 * Open the Electronic Passport modal for a specific user (admin-only view).
 * Admins can see every member's passport this way.
 */
window.openPassportModal = function(id) {
  const user = allUsers.find(u => u.id === id);
  if (!user) return;

  passportModalBody.innerHTML = buildPassportCardHTML(user);
  passportModal.classList.add('active');
};

function closePassportModal() {
  passportModal.classList.remove('active');
}

// ==================== METRICS & UTILITIES ====================

/**
 * Update Top Metric Stat Cards
 */
function updateMetrics() {
  // Total Users
  statTotalUsers.textContent = allUsers.length;

  // Next Assigned ID (matches server logic: baza.length > 0 ? baza[baza.length - 1].id + 1 : 1)
  const nextId = allUsers.length > 0 
    ? (allUsers[allUsers.length - 1].id + 1)
    : 1;
  statNextId.textContent = `#${nextId}`;
  anticipatedIdBadge.textContent = `#${nextId}`;

  // Average Age
  if (allUsers.length > 0) {
    const sumAge = allUsers.reduce((acc, curr) => acc + (Number(curr.age) || 0), 0);
    const avg = Math.round(sumAge / allUsers.length);
    statAvgAge.textContent = `${avg} yrs`;
  } else {
    statAvgAge.textContent = '0 yrs';
  }
}

/**
 * Set visual indicator for server connection
 */
function setBackendStatus(isOnline) {
  if (isOnline) {
    statusDot.className = 'status-dot online';
    statusLabel.textContent = 'Backend Connected';
    statusLabel.style.color = '#10b981';
  } else {
    statusDot.className = 'status-dot offline';
    statusLabel.textContent = 'Backend Offline';
    statusLabel.style.color = '#ef4444';
  }
}

/**
 * Show a gold toast notification
 */
function showToast(message, type = 'success') {
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;

  const iconClass = type === 'success' 
    ? 'fa-solid fa-circle-check' 
    : 'fa-solid fa-triangle-exclamation';

  toast.innerHTML = `
    <i class="${iconClass} toast-icon"></i>
    <span class="toast-message">${escapeHTML(message)}</span>
  `;

  toastContainer.appendChild(toast);

  setTimeout(() => {
    toast.style.animation = 'toastOut 0.3s forwards ease';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

/**
 * Extract 2 uppercase initials from a name
 */
function getInitials(name) {
  if (!name) return 'U';
  const parts = name.trim().split(/\s+/);
  if (parts.length >= 2) {
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }
  return parts[0].slice(0, 2).toUpperCase();
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHTML(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
