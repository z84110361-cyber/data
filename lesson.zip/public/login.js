/**
 * AURA ROYAL GOLD - AUTH PAGE SCRIPT
 * Handles Login & Register, then routes the user to the right place:
 *  - admin  -> index.html (Admin Panel, sees every passport)
 *  - user   -> passport.html (their own electronic passport)
 */

const API_BASE = (window.location.protocol === 'http:' || window.location.protocol === 'https:') && window.location.port === '4040'
  ? ''
  : 'http://localhost:4040';

// If already logged in, skip straight to the right destination
(function redirectIfLoggedIn() {
  const token = localStorage.getItem('auraToken');
  const userRaw = localStorage.getItem('auraUser');
  if (token && userRaw) {
    try {
      const user = JSON.parse(userRaw);
      window.location.href = user.role === 'admin' ? 'index.html' : 'passport.html';
    } catch (e) {
      localStorage.removeItem('auraToken');
      localStorage.removeItem('auraUser');
    }
  }
})();

const tabLoginBtn = document.getElementById('tabLoginBtn');
const tabRegisterBtn = document.getElementById('tabRegisterBtn');
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const toastContainer = document.getElementById('toastContainer');

tabLoginBtn.addEventListener('click', () => switchTab('login'));
tabRegisterBtn.addEventListener('click', () => switchTab('register'));

function switchTab(which) {
  const isLogin = which === 'login';
  tabLoginBtn.classList.toggle('active', isLogin);
  tabRegisterBtn.classList.toggle('active', !isLogin);
  loginForm.classList.toggle('active', isLogin);
  registerForm.classList.toggle('active', !isLogin);
}

function saveSessionAndRedirect(data) {
  localStorage.setItem('auraToken', data.token);
  localStorage.setItem('auraUser', JSON.stringify(data.user));
  window.location.href = data.user.role === 'admin' ? 'index.html' : 'passport.html';
}

loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = document.getElementById('loginUsername').value.trim();
  const password = document.getElementById('loginPassword').value;
  const btn = document.getElementById('loginSubmitBtn');

  if (!username || !password) {
    showToast('Login va parolni kiriting.', 'danger');
    return;
  }

  btn.disabled = true;
  btn.style.opacity = '0.7';
  try {
    const res = await fetch(`${API_BASE}/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Kirishda xatolik');

    showToast(`Xush kelibsiz, ${data.user.fullname}! ✨`, 'success');
    setTimeout(() => saveSessionAndRedirect(data), 500);
  } catch (err) {
    showToast(err.message, 'danger');
  } finally {
    btn.disabled = false;
    btn.style.opacity = '1';
  }
});

registerForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const fullname = document.getElementById('regFullname').value.trim();
  const username = document.getElementById('regUsername').value.trim();
  const age = parseInt(document.getElementById('regAge').value, 10);
  const password = document.getElementById('regPassword').value;
  const btn = document.getElementById('registerSubmitBtn');

  if (!fullname || !username || isNaN(age) || !password) {
    showToast('Barcha maydonlarni to\'g\'ri to\'ldiring.', 'danger');
    return;
  }

  btn.disabled = true;
  btn.style.opacity = '0.7';
  try {
    const res = await fetch(`${API_BASE}/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fullname, username, age, password })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Ro\'yxatdan o\'tishda xatolik');

    showToast(`Pasportingiz tayyor: ${data.user.passportNumber || ''} 🪪`, 'success');
    setTimeout(() => saveSessionAndRedirect(data), 600);
  } catch (err) {
    showToast(err.message, 'danger');
  } finally {
    btn.disabled = false;
    btn.style.opacity = '1';
  }
});

function showToast(message, type = 'success') {
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  const iconClass = type === 'success' ? 'fa-solid fa-circle-check' : 'fa-solid fa-triangle-exclamation';
  toast.innerHTML = `<i class="${iconClass} toast-icon"></i><span class="toast-message">${escapeHTML(message)}</span>`;
  toastContainer.appendChild(toast);
  setTimeout(() => {
    toast.style.animation = 'toastOut 0.3s forwards ease';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

function escapeHTML(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
