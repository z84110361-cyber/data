/**
 * AURA ROYAL GOLD - SHARED ELECTRONIC PASSPORT CARD RENDERER
 * Used by passport.html (own passport) and index.html admin panel (any user).
 */

function paspEscapeHTML(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function paspInitials(name) {
  if (!name) return 'U';
  const parts = name.trim().split(/\s+/);
  if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
  return parts[0].slice(0, 2).toUpperCase();
}

function paspFormatDate(dateStr) {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return '—';
  const dd = String(d.getDate()).padStart(2, '0');
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const yyyy = d.getFullYear();
  return `${dd}.${mm}.${yyyy}`;
}

/**
 * Build the HTML for a single electronic passport card.
 * @param {Object} user - user object as returned by /me or /users/:id
 * @returns {string} HTML string
 */
function buildPassportCardHTML(user) {
  const initials = paspInitials(user.fullname);
  const roleLabel = user.role === 'admin' ? 'ADMINISTRATOR' : 'FUQARO (USER)';
  const roleClass = user.role === 'admin' ? 'passport-role-admin' : 'passport-role-user';

  return `
    <div class="passport-card">
      <div class="passport-card-glare"></div>
      <div class="passport-card-header">
        <div class="passport-country">
          <i class="fa-solid fa-crown"></i>
          <div>
            <span class="passport-country-name">${paspEscapeHTML(user.nationality || "O'ZBEKISTON / UZB")}</span>
            <span class="passport-doc-type">ELEKTRON SHAXSIY PASPORT</span>
          </div>
        </div>
        <span class="passport-role-tag ${roleClass}">${roleLabel}</span>
      </div>

      <div class="passport-card-body">
        <div class="passport-photo">${initials}</div>

        <div class="passport-fields">
          <div class="passport-field">
            <span class="passport-field-label">To'liq ism (Full name)</span>
            <span class="passport-field-value">${paspEscapeHTML(user.fullname)}</span>
          </div>
          <div class="passport-field-row">
            <div class="passport-field">
              <span class="passport-field-label">Foydalanuvchi (Username)</span>
              <span class="passport-field-value">${paspEscapeHTML(user.username || '—')}</span>
            </div>
            <div class="passport-field">
              <span class="passport-field-label">Yosh (Age)</span>
              <span class="passport-field-value">${paspEscapeHTML(String(user.age))}</span>
            </div>
          </div>
          <div class="passport-field-row">
            <div class="passport-field">
              <span class="passport-field-label">Reyestr ID</span>
              <span class="passport-field-value font-mono">#${paspEscapeHTML(String(user.id))}</span>
            </div>
            <div class="passport-field">
              <span class="passport-field-label">Berilgan sana</span>
              <span class="passport-field-value">${paspFormatDate(user.passportIssuedAt || user.createdAt)}</span>
            </div>
          </div>
        </div>
      </div>

      <div class="passport-card-footer">
        <div class="passport-number-box">
          <span class="passport-field-label">PASPORT RAQAMI</span>
          <span class="passport-number">${paspEscapeHTML(user.passportNumber || 'ISSUING...')}</span>
        </div>
        <div class="passport-status-box">
          <span class="passport-status-dot"></span>
          <span>FAOL (ACTIVE)</span>
        </div>
      </div>
    </div>
  `;
}
