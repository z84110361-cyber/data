const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  id: {
    type: Number,
    unique: true
  },
  fullname: {
    type: String,
    required: [true, 'Full name is required'],
    trim: true
  },
  username: {
    type: String,
    unique: true,
    sparse: true,
    trim: true,
    lowercase: true
  },
  email: {
    type: String,
    unique: true,
    sparse: true,
    trim: true,
    lowercase: true
  },
  password: {
    type: String,
    trim: true
  },
  age: {
    type: Number,
    required: [true, 'Age is required'],
    min: 0,
    max: 150
  },
  role: {
    type: String,
    enum: ['user', 'admin'],
    default: 'user'
  },
  // Electronic passport fields — issued automatically the moment a user registers
  passportNumber: {
    type: String,
    unique: true,
    sparse: true
  },
  passportIssuedAt: {
    type: Date,
    default: Date.now
  },
  nationality: {
    type: String,
    default: 'O\'ZBEKISTON / UZB'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true,
  toJSON: {
    transform: function(doc, ret) {
      delete ret.password;
      delete ret.__v;
      return ret;
    }
  },
  toObject: {
    transform: function(doc, ret) {
      delete ret.password;
      delete ret.__v;
      return ret;
    }
  }
});

// Generates a random Uzbekistan-style e-passport number, e.g. "AB1234567"
function generatePassportNumber() {
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const l1 = letters[Math.floor(Math.random() * letters.length)];
  const l2 = letters[Math.floor(Math.random() * letters.length)];
  const digits = Math.floor(1000000 + Math.random() * 9000000); // 7 digits
  return `${l1}${l2}${digits}`;
}

// Auto-assign sequential numeric ID before saving if not present
userSchema.pre('save', async function() {
  if (this.isNew && !this.id) {
    const highestUser = await this.constructor.findOne().sort({ id: -1 }).select('id');
    this.id = (highestUser && highestUser.id) ? highestUser.id + 1 : 1;
  }

  // Issue an electronic passport number the moment the user is created
  if (this.isNew && !this.passportNumber) {
    let candidate;
    let attempts = 0;
    do {
      candidate = generatePassportNumber();
      attempts++;
      // eslint-disable-next-line no-await-in-loop
      var exists = await this.constructor.findOne({ passportNumber: candidate });
    } while (exists && attempts < 8);
    this.passportNumber = candidate;
    this.passportIssuedAt = new Date();
  }

  // Hash password if modified and exists
  if (this.isModified('password') && this.password) {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
  }
});

// Password verification method
userSchema.methods.comparePassword = async function(candidatePassword) {
  if (!this.password) return false;
  return bcrypt.compare(candidatePassword, this.password);
};

module.exports = mongoose.model('User', userSchema);
