require('dotenv').config()
const express = require('express')
const path = require('path')
const mongoose = require('mongoose')
const jwt = require('jsonwebtoken')
const swaggerUi = require('swagger-ui-express')
const swaggerJsdoc = require('swagger-jsdoc')
const User = require('./models/User')

const app = express()
const PORT = process.env.PORT || 4040
const JWT_SECRET = process.env.JWT_SECRET || 'my_super_secret_key_123456'

// Connect to MongoDB
let mongoUri = process.env.MONGO_URI || process.env.MONGOSEE || 'mongodb://127.0.0.1:27017/user_database'
if (mongoUri.includes('<db_password>')) {
    // If user has unreplaced Atlas placeholder, fallback to local MongoDB
    mongoUri = 'mongodb://127.0.0.1:27017/user_database'
}

mongoose.connect(mongoUri)
    .then(async () => {
        console.log(` Connected to MongoDB: ${mongoUri}`)
        // Seed default users if database is empty
        const count = await User.countDocuments()
        if (count === 0) {
            console.log(' Seeding initial users into MongoDB...')
            const initialUsers = [
                {
                    id: 1,
                    fullname: 'Behruz Sotimboyev',
                    username: 'behruz',
                    password: '123',
                    age: 21,
                    role: 'admin'
                },
                {
                    id: 2,
                    fullname: 'Shodi Shuxratov',
                    username: 'shodi',
                    password: '123',
                    age: 15,
                    role: 'user'
                }
            ]
            for (const u of initialUsers) {
                const newUser = new User(u)
                await newUser.save()
            }
            console.log(' Default users seeded successfully!')
        }

        // Make sure the main admin account always exists, even on a database
        // that was already seeded before this account was introduced.
        const existingAdmin = await User.findOne({ username: 'admin' })
        if (!existingAdmin) {
            const adminUser = new User({
                fullname: 'Bosh Administrator',
                username: 'admin',
                password: 'uzbe11',
                age: 30,
                role: 'admin'
            })
            await adminUser.save()
            console.log(' Default admin account created (admin / uzbe11)')
        }
    })
    .catch((err) => {
        console.error(' MongoDB Connection Error:', err.message)
    })

app.use(express.json())

// CORS middleware
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*')
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS')
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization')
    if (req.method === 'OPTIONS') {
        return res.sendStatus(200)
    }
    next()
})

// Authentication Middleware
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization']
    const token = authHeader && authHeader.split(' ')[1]

    if (!token) {
        return res.status(401).json({ error: 'Token mavjud emas (Access denied, token missing)' })
    }

    jwt.verify(token, JWT_SECRET, (err, decoded) => {
        if (err) {
            return res.status(403).json({ error: 'Token yaroqsiz yoki muddati o\'tgan (Invalid or expired token)' })
        }
        req.user = decoded
        next()
    })
}

// Requires a valid token AND role === 'admin'
function requireAdmin(req, res, next) {
    if (!req.user || req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Faqat administrator uchun ruxsat (Admins only)' })
    }
    next()
}

// Swagger API Documentation Config
const swaggerOptions = {
    definition: {
        openapi: '3.0.0',
        info: {
            title: 'Users & Authentication API Documentation',
            version: '2.0.0',
            description: 'Express.js backend MongoDB va JWT autentifikatsiyasi bilan ta\'minlangan API'
        },
        servers: [
            {
                url: `http://localhost:${PORT}`,
                description: 'Local server'
            }
        ],
        components: {
            securitySchemes: {
                bearerAuth: {
                    type: 'http',
                    scheme: 'bearer',
                    bearerFormat: 'JWT',
                    description: 'JWT tokenni kiriting (masalan: eyJhbGci...)'
                }
            },
            schemas: {
                User: {
                    type: 'object',
                    properties: {
                        _id: {
                            type: 'string',
                            example: '66fe7a2b904d983946278abc'
                        },
                        id: {
                            type: 'integer',
                            example: 1
                        },
                        fullname: {
                            type: 'string',
                            example: 'Behruz Sotimboyev'
                        },
                        username: {
                            type: 'string',
                            example: 'behruz'
                        },
                        email: {
                            type: 'string',
                            example: 'behruz@example.com'
                        },
                        age: {
                            type: 'integer',
                            example: 21
                        },
                        role: {
                            type: 'string',
                            example: 'user'
                        },
                        createdAt: {
                            type: 'string',
                            format: 'date-time'
                        }
                    }
                },
                UserInput: {
                    type: 'object',
                    required: ['fullname', 'age'],
                    properties: {
                        fullname: {
                            type: 'string',
                            example: 'Ali Valiyev'
                        },
                        age: {
                            type: 'integer',
                            example: 25
                        },
                        username: {
                            type: 'string',
                            example: 'ali_valiyev'
                        },
                        password: {
                            type: 'string',
                            example: 'password123'
                        }
                    }
                },
                RegisterInput: {
                    type: 'object',
                    required: ['fullname', 'username', 'password', 'age'],
                    properties: {
                        fullname: {
                            type: 'string',
                            example: 'Ali Valiyev'
                        },
                        username: {
                            type: 'string',
                            example: 'alivali'
                        },
                        email: {
                            type: 'string',
                            example: 'ali@example.com'
                        },
                        password: {
                            type: 'string',
                            example: 'secret123'
                        },
                        age: {
                            type: 'integer',
                            example: 25
                        }
                    }
                },
                LoginInput: {
                    type: 'object',
                    required: ['username', 'password'],
                    properties: {
                        username: {
                            type: 'string',
                            description: 'Username, email yoki fullname',
                            example: 'behruz'
                        },
                        password: {
                            type: 'string',
                            example: '123'
                        }
                    }
                },
                AuthResponse: {
                    type: 'object',
                    properties: {
                        message: {
                            type: 'string',
                            example: 'Muvaffaqiyatli tizimga kirildi'
                        },
                        token: {
                            type: 'string',
                            example: 'eyJhbGciOiJIUzI1NiIsIn...'
                        },
                        user: {
                            $ref: '#/components/schemas/User'
                        }
                    }
                }
            }
        },
        security: [
            {
                bearerAuth: []
            }
        ]
    },
    apis: ['./server.js', path.join(__dirname, 'server.js').replace(/\\/g, '/')]
}

const swaggerSpec = swaggerJsdoc(swaggerOptions)
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec))

app.use(express.static(path.join(__dirname, 'public')))
app.use(express.static(__dirname))

/**
 * @swagger
 * /api:
 *   get:
 *     summary: API holatini tekshirish
 *     tags: [General]
 *     security: []
 *     responses:
 *       200:
 *         description: API muvaffaqiyatli ishlamoqda
 */
app.get('/api', (req, res) => {
    res.json({
        status: 'online',
        message: 'API is working properly',
        database: mongoose.connection.readyState === 1 ? 'MongoDB Connected' : 'Connecting to MongoDB...'
    })
})

/**
 * @swagger
 * /register:
 *   post:
 *     summary: Yangi foydalanuvchini ro'yxatdan o'tkazish (Register)
 *     tags: [Auth]
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/RegisterInput'
 *     responses:
 *       201:
 *         description: Foydalanuvchi muvaffaqiyatli yaratildi va token berildi
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/AuthResponse'
 *       400:
 *         description: Kerakli ma'lumotlar kiritilmagan yoki foydalanuvchi allaqachon mavjud
 */
const handleRegister = async (req, res) => {
    try {
        const { fullname, username, email, password, age } = req.body

        if (!fullname || age === undefined) {
            return res.status(400).json({ error: 'fullname va age maydonlari majburiy' })
        }

        // Check if username or email already exists
        if (username) {
            const existingUsername = await User.findOne({ username: username.toLowerCase() })
            if (existingUsername) {
                return res.status(400).json({ error: 'Bu username allaqachon mavjud' })
            }
        }

        if (email) {
            const existingEmail = await User.findOne({ email: email.toLowerCase() })
            if (existingEmail) {
                return res.status(400).json({ error: 'Bu email allaqachon mavjud' })
            }
        }

        const newUser = new User({
            fullname,
            username: username ? username.toLowerCase() : undefined,
            email: email ? email.toLowerCase() : undefined,
            password: password || undefined,
            age: Number(age)
        })

        await newUser.save()

        const token = jwt.sign(
            { id: newUser.id, _id: newUser._id, username: newUser.username, fullname: newUser.fullname, role: newUser.role },
            JWT_SECRET,
            { expiresIn: '7d' }
        )

        res.status(201).json({
            message: 'Foydalanuvchi muvaffaqiyatli ro‘yxatdan o‘tdi',
            token,
            user: newUser
        })
    } catch (error) {
        console.error('Register error:', error)
        res.status(500).json({ error: error.message || 'Server xatosi ro‘yxatdan o‘tishda' })
    }
}
app.post('/register', handleRegister)
app.post('/api/register', handleRegister)

/**
 * @swagger
 * /login:
 *   post:
 *     summary: Tizimga kirish (Login)
 *     tags: [Auth]
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/LoginInput'
 *     responses:
 *       200:
 *         description: Tizimga kirildi va JWT token berildi
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/AuthResponse'
 *       400:
 *         description: Login va parol kiritilmagan
 *       401:
 *         description: Noto'g'ri parol
 *       404:
 *         description: Bunday foydalanuvchi bazada topilmadi
 */
const handleLogin = async (req, res) => {
    try {
        const { username, password } = req.body

        if (!username || !password) {
            return res.status(400).json({ error: 'Username (yoki email) va parol kiritilishi shart' })
        }

        const searchIdentifier = username.trim()
        // Find user by username, email, or fullname (case-insensitive for username/email)
        const user = await User.findOne({
            $or: [
                { username: searchIdentifier.toLowerCase() },
                { email: searchIdentifier.toLowerCase() },
                { fullname: searchIdentifier }
            ]
        })

        if (!user) {
            return res.status(404).json({ error: 'Bunday foydalanuvchi bazada topilmadi (User not found in database)' })
        }

        // If user has password, check it
        if (user.password) {
            const isMatch = await user.comparePassword(password)
            if (!isMatch) {
                return res.status(401).json({ error: 'Noto\'g\'ri parol (Incorrect password)' })
            }
        } else {
            // If user has no password set yet, set this as their password
            user.password = password
            await user.save()
        }

        const token = jwt.sign(
            { id: user.id, _id: user._id, username: user.username, fullname: user.fullname, role: user.role },
            JWT_SECRET,
            { expiresIn: '7d' }
        )

        res.json({
            message: 'Muvaffaqiyatli tizimga kirildi',
            token,
            user
        })
    } catch (error) {
        console.error('Login error:', error)
        res.status(500).json({ error: error.message || 'Server xatosi login qilishda' })
    }
}
app.post('/login', handleLogin)
app.post('/api/login', handleLogin)

/**
 * @swagger
 * /me:
 *   get:
 *     summary: Hozirgi kirgan foydalanuvchi ma'lumotlarini olish (JWT bilan)
 *     tags: [Auth]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Foydalanuvchi ma'lumotlari
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
 *       401:
 *         description: Token taqdim etilmagan
 *       404:
 *         description: Foydalanuvchi topilmadi
 */
const handleMe = async (req, res) => {
    try {
        const user = await User.findById(req.user._id) || await User.findOne({ id: req.user.id })
        if (!user) {
            return res.status(404).json({ error: 'Foydalanuvchi bazada topilmadi' })
        }
        res.json(user)
    } catch (error) {
        res.status(500).json({ error: error.message })
    }
}
app.get('/me', authenticateToken, handleMe)
app.get('/api/me', authenticateToken, handleMe)

/**
 * Helper to find user by numeric id or MongoDB _id
 */
async function findUserByIdParam(idParam) {
    if (!isNaN(idParam)) {
        const byNumeric = await User.findOne({ id: Number(idParam) })
        if (byNumeric) return byNumeric
    }
    if (mongoose.Types.ObjectId.isValid(idParam)) {
        const byMongoId = await User.findById(idParam)
        if (byMongoId) return byMongoId
    }
    return null
}

/**
 * @swagger
 * /users:
 *   get:
 *     summary: Barcha foydalanuvchilarni olish (MongoDB dan)
 *     tags: [Users]
 *     responses:
 *       200:
 *         description: Foydalanuvchilar ro'yxati (barcha elektron pasportlar, faqat admin)
 *       403:
 *         description: Faqat administrator uchun ruxsat
 */
app.get('/users', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const users = await User.find().sort({ id: 1 })
        res.json(users)
    } catch (error) {
        console.error('Error fetching users:', error)
        res.status(500).json({ error: 'Foydalanuvchilarni olishda xatolik yuz berdi' })
    }
})

/**
 * @swagger
 * /users/{id}:
 *   get:
 *     summary: Foydalanuvchini ID bo'yicha olish (elektron pasporti bilan)
 *     tags: [Users]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: Foydalanuvchi ID raqami yoki MongoDB _id
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Foydalanuvchi ma'lumotlari
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
 *       403:
 *         description: Boshqa foydalanuvchi pasportini ko'rish taqiqlangan
 *       404:
 *         description: User topilmadi
 */
app.get('/users/:id', authenticateToken, async (req, res) => {
    try {
        const user = await findUserByIdParam(req.params.id)
        if (!user) {
            return res.status(404).send('User topilmadi')
        }

        // Privacy: a normal user may only view their own electronic passport.
        // Admins can view everyone's.
        const isOwner = req.user.id === user.id || req.user._id === String(user._id)
        if (req.user.role !== 'admin' && !isOwner) {
            return res.status(403).json({ error: 'Boshqa foydalanuvchi pasportini ko\'rish taqiqlangan' })
        }

        res.json(user)
    } catch (error) {
        console.error('Error getting user:', error)
        res.status(500).json({ error: 'Server xatosi' })
    }
})

/**
 * @swagger
 * /users:
 *   post:
 *     summary: Yangi foydalanuvchi qo'shish (MongoDB ga saqlash, faqat admin)
 *     tags: [Users]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UserInput'
 *     responses:
 *       201:
 *         description: Foydalanuvchi muvaffaqiyatli yaratildi
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
 *       400:
 *         description: fullname va age kerak
 */
app.post('/users', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const { fullname, age, username, password, email } = req.body

        if (!fullname || age === undefined) {
            return res.status(400).send('fullname va age kerak')
        }

        const newUser = new User({
            fullname: fullname.trim(),
            age: Number(age),
            username: username ? username.trim().toLowerCase() : undefined,
            email: email ? email.trim().toLowerCase() : undefined,
            password: password || undefined
        })

        await newUser.save()

        res.status(201).json(newUser)
    } catch (error) {
        console.error('Error adding user:', error)
        res.status(500).json({ error: error.message || 'Foydalanuvchi qo‘shishda xatolik' })
    }
})

/**
 * @swagger
 * /users/{id}:
 *   delete:
 *     summary: Foydalanuvchini o'chirish (MongoDB dan, faqat admin)
 *     tags: [Users]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: Foydalanuvchi ID raqami
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Foydalanuvchi muvaffaqiyatli o'chirildi
 *       404:
 *         description: User topilmadi
 */
app.delete('/users/:id', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const user = await findUserByIdParam(req.params.id)

        if (!user) {
            return res.status(404).send('User topilmadi')
        }

        await User.deleteOne({ _id: user._id })

        res.send('Пользователь удалён')
    } catch (error) {
        console.error('Error deleting user:', error)
        res.status(500).json({ error: 'Foydalanuvchini o‘chirishda xatolik' })
    }
})

/**
 * @swagger
 * /users/{id}:
 *   put:
 *     summary: Foydalanuvchi ma'lumotlarini yangilash (faqat admin)
 *     tags: [Users]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: Foydalanuvchi ID raqami
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UserInput'
 *     responses:
 *       200:
 *         description: Yangilangan foydalanuvchi ma'lumotlari
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
 *       400:
 *         description: fullname va age kerak
 *       404:
 *         description: User topilmadi
 */
app.put('/users/:id', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const { fullname, age, username, email } = req.body

        if (!fullname || age === undefined) {
            return res.status(400).send('fullname va age kerak')
        }

        const user = await findUserByIdParam(req.params.id)

        if (!user) {
            return res.status(404).send('User topilmadi')
        }

        user.fullname = fullname.trim()
        user.age = Number(age)
        if (username !== undefined) user.username = username ? username.trim().toLowerCase() : undefined
        if (email !== undefined) user.email = email ? email.trim().toLowerCase() : undefined

        await user.save()

        res.json(user)
    } catch (error) {
        console.error('Error updating user:', error)
        res.status(500).json({ error: error.message || 'Foydalanuvchini yangilashda xatolik' })
    }
})

/**
 * @swagger
 * /users/{id}:
 *   patch:
 *     summary: Foydalanuvchi ma'lumotlarini qisman yangilash (faqat admin)
 *     tags: [Users]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: Foydalanuvchi ID raqami
 *         schema:
 *           type: string
 *     requestBody:
 *       required: false
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               fullname:
 *                 type: string
 *                 example: Ali Valiyev
 *               age:
 *                 type: integer
 *                 example: 26
 *               username:
 *                 type: string
 *                 example: ali26
 *     responses:
 *       200:
 *         description: Yangilangan foydalanuvchi ma'lumotlari
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/User'
 *       404:
 *         description: User topilmadi
 */
app.patch('/users/:id', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const { fullname, age, username, email } = req.body

        const user = await findUserByIdParam(req.params.id)

        if (!user) {
            return res.status(404).send('User topilmadi')
        }

        if (fullname !== undefined) {
            user.fullname = fullname.trim()
        }

        if (age !== undefined) {
            user.age = Number(age)
        }

        if (username !== undefined) {
            user.username = username ? username.trim().toLowerCase() : undefined
        }

        if (email !== undefined) {
            user.email = email ? email.trim().toLowerCase() : undefined
        }

        await user.save()

        res.json(user)
    } catch (error) {
        console.error('Error patching user:', error)
        res.status(500).json({ error: error.message || 'Foydalanuvchini yangilashda xatolik' })
    }
})

// Start server
const server = app.listen(PORT, () => {
    console.log(` Server is running on http://localhost:${PORT}`)
    console.log(` Swagger documentation: http://localhost:${PORT}/api-docs`)
})

module.exports = { app, server }